# PulseVisuals

Сборка:
    ./gradlew build
Готовый jar: build/libs/pulsevisuals-1.0.0.jar

Для запуска в Minecraft 1.21.11 положите jar в папку mods вместе с Fabric API.
Перед сборкой проверьте версии в gradle.properties на fabricmc.net/develop.
